package uk.ac.tees.mad.memorylog

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MemoryLogApplication : Application()