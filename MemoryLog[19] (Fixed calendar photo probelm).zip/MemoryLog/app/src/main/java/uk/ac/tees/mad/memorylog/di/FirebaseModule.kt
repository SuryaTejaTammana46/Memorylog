package uk.ac.tees.mad.memorylog.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {

//    @Provides
//    @Singleton
//    fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()
//
//    @Provides
//    @Singleton
//    fun provideFirestore(): FirebaseFirestore = FirebaseFirestore.getInstance()
//
//    @Provides
//    @Singleton
//    fun provideFirebaseStorage(): FirebaseStorage = FirebaseStorage.getInstance()

//    @Provides
//    @Singleton
//    fun provideAuthDataSource(
//        auth: FirebaseAuth,
//        db: FirebaseFirestore
//    ) = FirebaseAuthDataSource(auth, db)
}